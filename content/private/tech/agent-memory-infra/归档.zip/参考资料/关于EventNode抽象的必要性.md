# 结论：

> **从“知识图谱定义”上说，`EventNode` 不是必须的；**
> **但从 Agent Memory / Session + Trace / Temporal KG 的工程目标看，建议保留。**
> 而且更建议的是：**保留一个“最小 EventNode”概念，而不是做一个很重的 Event ontology。**

再说得更直接一点：

> **不一定非要叫 `EventNode`，但必须有“==把一次发生的事情对象化==”的能力。**
> 否则后面很可能会在边属性、JSON blob、或者某种中间 fact 结构里，把它偷偷再发明一遍。

---

# 1. `EventNode` 的本质好处是什么？

本质上它解决的是这个问题：

> **“一次发生”不是一个普通实体，也不是一条简单边。**

比如这件事：

- `python_executor`
- 在 `10:02`
- 执行了 `read_excel`
- 处理的是 `sales.xlsx`
- 状态是 `success`
- 耗时 `420ms`
- 生成了 `summary_report.xlsx`
- 来源于某个 trace block
- 属于某个 session
- 这个事件和前一个事件有 `PRECEDES`
- 这个事件和某个用户请求有 `REQUEST_LEADS_TO`

你会发现，这已经不是一个简单的：

```text
A --uses--> B
```

能表达清楚的东西了。

所以 `EventNode` 的第一价值是：

## 1）把“多元关系”变成一个一等对象

这是知识建模里很经典的一件事，叫 **reification / 事件化**。

如果没有 `EventNode`，只能把信息硬塞到边上：

```text
python_executor -[:INVOKES {
  action: "read_excel",
  time: "...",
  status: "success",
  latency_ms: 420,
  session_id: "...",
  source_block_id: "...",
  confidence: 0.86
}]-> read_excel
```

问题是马上就来了：

- 处理对象 `sales.xlsx` 挂哪？
- 产出的 artifact 挂哪？
- 失败重试关系挂哪？
- 前后时序关系挂哪？
- 用户请求和这次执行的映射挂哪？

边会越来越臃肿，最后变得不可维护。

---

# 2. 它的实际用处是什么？

我觉得有 4 个最核心的用处。

---

## 用处 1：支撑“时序链”和“因果链”

我们很关注：

- `PRECEDES`
- `FOLLOWS`
- `caused_by`
- `REQUEST_LEADS_TO`
- 自动因果链修复
- 时间线回放

这些关系最自然的连接对象，其实不是实体，而是**事件**。

因为：

- 实体是“是什么”
- 事件是“发生了什么”
- 时间顺序发生在“事”和“事”之间，不主要发生在“物”和“物”之间

例如：

```text
用户提出需求
  -> 选择工具
  -> 调用 read_excel
  -> 生成 artifact
  -> 返回结果
```

这本质上是一条**事件链**。

如果没有 `EventNode`，你会被迫把时序链挂在一些不合适的对象上：

- 挂在 session turn 上，太粗
- 挂在 tool/entity 上，语义不准
- 挂在边上，又会很乱

所以：

> **要做 Temporal KG，事件往往要成为主角之一。**

---

## 用处 2：把 provenance / evidence 放在正确的位置

我们一直在强调：

- `source_block_id`
- `source_block_ids`
- `source_uri`
- `confidence`
- `resolution_method`
- `status`
- `valid_at / invalid_at / superseded_at`

这些信息到底是属于谁的？

很多时候它们既不属于实体本身，也不属于某个普通关系本身，而是属于：

> **“这一次被抽取出来的事件事实”**

举个例子：

- `pandas` 这个实体本身是稳定的
- 但“这次会话里用户说昨天用 pandas 处理 CSV”这个事，是带来源和置信度的

这时最自然就是：

- `EntityNode(pandas)` = 稳定对象
- `EventNode(uses_pandas_for_csv)` = 这次发生/被提到的事实
- `RawBlockRef` = 证据

这样 provenance 就非常干净。

---

## 用处 3：作为 Session / Trace 融合的锚点

这是我们场景里**最重要**的一点。

我们不是做百科知识图谱，也不是只做文档图谱；我们做的是：

- 会话输入
- trace 执行
- 两条链路
- 最后融合成**一个可回忆、可检索、可推理的记忆图谱**

这里面有一个很大的工程问题：

> Session 说的是“用户想做什么 / 提到了什么”
> Trace 说的是“系统实际上做了什么”

这两者如果只靠实体直接连，很容易变粗糙。

但如果中间有 `EventNode`，就顺很多：

### Session 侧
- 用户请求“帮我把 Excel 也读进来”
- 抽成一个请求事件 `EventNode(request_read_excel)`

### Trace 侧
- 系统实际调用了 `python_executor.read_excel`
- 抽成一个执行事件 `EventNode(tool_use_read_excel)`

然后二者之间可以建立：

- `REQUEST_LEADS_TO`
- `ALIGNS_WITH`
- `PARTIALLY_SATISFIES`
- `FAILED_TO_FULFILL`

这就把“说过的话”和“做过的事”接上了。

如果没有 `EventNode`，你就只能：

- 用户 -> Excel
- 工具 -> read_excel
- 然后硬猜它们是同一件事

这会弱很多。

---

## 用处 4：让 retrieval / replay / debugging 更自然

我们后面大概率会需要回答这种问题：

- 上次**什么时候**用过 `read_excel`？
- 哪次失败后又重试成功了？
- 哪一步生成了最终 artifact？
- 这个结论来自哪条 trace？
- 用户提过的需求，系统后来有没有真正执行？
- 哪些事件构成了“导出报表”这条路径？

这些问题本质上是在找：

> **一个个发生过的事件，以及事件之间的关系**

如果没有 `EventNode`，很多查询会变成：

- 在不同边属性里翻时间
- 在 block 里做文本对齐
- 在多个 entity-edge 组合里拼事实

可做，但会很拧巴。

---

# 3. 那么，`EventNode` 有“必要”吗？

我的判断是：

## 如果只是做很轻量的实体记忆：不一定有必要

比如你只想要：

- 用户喜欢什么
- 某个工具和某个概念有关
- 文档里有哪些术语关系

那完全可以只有：

- `EntityNode`
- `RELATES_TO`
- 少量 provenance

这类系统不一定要单独建事件节点。

---

## 但如果要做的是“动态 Agent Memory”：有必要

尤其我们现在明确要做的包括：

- Session / Trace 双来源
- Temporal KG
- 时序边
- 因果链
- provenance-first
- Graph RAG / 多跳检索
- artifact 生命周期
- 事件级 confidence

那我会说：

> **`EventNode` 不是奢侈品，而是结构清晰的关键部件。**

---

# 4. 更准确地说：不是“有没有 EventNode”，而是“事件要不要对象化”

这个 distinction 很重要。

你可以不叫它 `EventNode`，比如叫：

- `FactEvent`
- `InteractionEvent`
- `MemoryEvent`
- `ActivityNode`

都行。

但只要你想表达：

- 一次工具调用
- 一次用户决策
- 一次偏好更新
- 一次 artifact 创建
- 一次错误与恢复
- 一次计划变更

你最终都会需要一个“事件对象”。

所以我觉得更本质的说法是：

> **不是必须有 `EventNode` 这个名字，但几乎必须有等价的事件对象层。**

---

# 5. 如果没有 `EventNode`，会怎么样？

给一个最现实的判断：

> 短期看，会显得简单；
> 中期看，边和属性会越来越脏；
> 长期看，你会重新把它做回来。

典型症状会是：

---

## 症状 1：边属性爆炸

一开始你会觉得：

```text
python_executor -[:INVOKES]-> read_excel
```

挺简单。

然后慢慢加上：

- 时间
- 状态
- latency
- source_block_ids
- session_id
- confidence
- resolution_method
- retry_count
- artifact_uri
- user_request_id

最后这条边会变成一个“小型对象”。

那其实你已经在偷偷模拟 `EventNode` 了。

---

## 症状 2：无法优雅表达多参与者事件

很多事件不是二元的，而是多元的：

- 执行者
- 操作
- 输入对象
- 输出对象
- 上下文 session
- 来源 block

单一边很难承载这种结构。

---

## 症状 3：时序和因果建模越来越别扭

`PRECEDES` / `CAUSES` 这些关系本来就该连事件。

如果你没有事件节点，就只能：

- 把它们连在 block 之间
- 把它们连在 entity 之间
- 或者做一层“伪事件边”

都不如直接建事件对象干净。

---

# 6. 但要避免一个风险：`EventNode` 不要建得太重

这里也要讲清楚。

不是建议：

> “所有 turn、所有 token、所有动作、所有状态都变成 EventNode”

那会过度设计。

更推荐的是：

## 推荐方案：最小 EventNode

只把**高价值、可复用、可推理、可检索**的事件提炼出来。

例如只覆盖这些类型：

- `tool_use`
- `tool_result`
- `artifact_create`
- `error_occurred`
- `retry`
- `goal_commit`
- `preference_update`
- `decision`
- `observation`
- `task_complete`

而不是每句自然语言、每个低价值动作都建。

---

# 7. 我建议的 3 个方案

## 方案 A：不要 `EventNode`
只保留：
- `EntityNode`
- 实体关系边
- `RawBlockRef`

### 优点
- 简单
- 原型快

### 缺点
- 时序链弱
- provenance 容易脏
- Session/Trace 融合会比较别扭
- 未来大概率返工

### 适用
- 只做 very early MVP
- 只验证最基本的抽取/存储

---

## 方案 B：全面 `EventNode`
把大多数行为都事件化。

### 优点
- 表达力强
- 时序/因果/回放能力最好

### 缺点
- 模型变重
- 抽取规则复杂
- 早期原型成本高

### 适用
- 中后期
- 已经明确要做事件级 reasoning

---

## 方案 C：最小 `EventNode`（**我推荐**）
只事件化高价值行为。

### 优点
- 保住关键能力
- 不会过重
- 和 Graphiti / provenance-first 思路兼容
- 适合当前原型

### 缺点
- 需要先定义“哪些事件值得提炼”
- 会有一部分灰区

### 适用
- 现在这个阶段最合适

---

# 8. 为什么我推荐“最小 EventNode”

因为当前目标不是做一套完美 ontology，而是：

- 能指导原型开发
- 结构不歧义
- Session / Trace 可以融合
- 后面可以接 Graph RAG / 时序推理
- 不把自己锁死

而“最小 EventNode”刚好兼顾：

- **简单度**
- **表达力**
- **可扩展性**

---

# 9. 和 Graphiti 的关系怎么理解？

其实这里可以说得非常直白：

> Graphiti 的强项是把 episode / entity / fact / provenance 组织好；
> 我们把 `EventNode` 提出来，本质上是在 Graphiti 那种“事实抽取”之上，再往前走一步，**把“事件性事实”显式对象化。**

也就是说：

- Graphiti 更偏 **episodic evidence + fact**
- 我们的 `EventNode` 更偏 **event graph**

这不是冲突，而是：

> **为了更好承载 Agent trace、时序链和行为记忆，做的一层增强。**

---

# 10. 最后给一句最推荐的判断

> **有必要保留 `EventNode` 概念，但应收敛为“最小事件层”，只对高价值行为和关键记忆单元做事件化。**

再压缩一点：

> **不是为了概念好看才建 `EventNode`，而是为了把“发生过什么”从“是什么”里分离出来。**

---

# 11. 一句话总结

**`EventNode` 的核心价值，不是多一种节点类型，而是让系统能稳定表达“发生了什么、何时发生、由谁触发、影响了什么、证据来自哪里、与前后事件什么关系”。**

如果没有这个层，短期能跑；  
但是，一旦认真做 **trace 融合、时序检索、因果链、artifact lineage、记忆回放**，大概率还是会把它重新做出来。
